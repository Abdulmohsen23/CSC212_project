package Project;

public class BT<T> 
{
	MNode<T> root, current;
	int counter;
	
	/** Creates a new instance of BT */
	public BT() {
		root = current = null;
		counter = 0;
	}
	
	public boolean empty(){
		return root == null;
	}
	
	public T retrieve() {
		return current.data;
	}

	
	public void update(T val) {
		current.data = val;
	}

	public boolean insert(Relative rel, T val) {
		switch(rel) 
		{
		   case Root:
			if(!empty()) 
				return false;
			current = root = new MNode<T>(val,counter);
			counter++;
			return true;
		   case Parent:	//This is an impossible case.
			return false;
		   case LeftChild:
			if(current.left != null)
				return false;
			current.left = new MNode<T>(val,counter);
			current = current.left;
			counter++;
			return true;
		   case RightChild:
			if(current.right != null) 
				return false;
			current.right = new MNode<T> (val,counter);
			current = current.right;
			counter++;
			return true;
		   default:
			return false;
		}
		
		
	}
	
	public void deleteSubtree()
	{
		if(current == root){
			current = root = null;
			counter = 0;
		}
		else {
			MNode<T> p = current;
			find(Relative.Parent);
			if(current.left == p)
				current.left = null;
			else 
				current.right = null;
			current = root;
						
		}
	}
	
	public boolean find(Relative rel){
		switch (rel) {
		   case Root:	// Easy case
			current = root;
			return true;
		   case Parent:
			if(current == root) return false;
			current = findparent(current, root);
			return true;
		   case LeftChild: 
			if(current.left == null) return false;
			current = current.left;
			return true;
		   case RightChild:
			if(current.right == null) return false;
			current = current.right;
			return true;
		   default:
			return false;
		}
	}


	private MNode<T> findparent(MNode<T> p, MNode<T> t) {
		if(t == null)
			return null;	// empty tree
		
		if(t.right == null && t.left == null)
			return null;
		else if(t.right == p || t.left == p)
			return t;	// parent is t
		else {
			MNode q = findparent(p, t.left);
			if (q != null)
				return q;
			else
				return findparent(p, t.right);
		}
	}

	// method to compare the node data to a given path
    private boolean compare(MNode <T> t, char path) // this function is O(1)
    {
        char value = t.data.toString().charAt(0); // O(1)
        return value == path; // O(1)
    }

    public void followPath(MNode<T> t, String path) // this function is O(n)
    {
        if (follow(t, path)) // O(n)
            System.out.println("The path " + path + " is valid"); // O(1)
        else
            System.out.println("The path " + path + " is not valid"); // O(1)
    }

    private boolean follow(MNode<T> t, String path) // this function is O(n)
    {
        // Check if the current node is null
        if (t == null) // O(1)
            return false; // O(1)
        
        // Compare last node
        if (path.length() == 1)  // O(n)
            return compare(t, path.charAt(0)); // O(1)
        
        // Cleaning the given string
        if (path.contains("-")) // O(n)
            path = path.replace("-", ""); //O(n)
        
        path = path.toUpperCase(); // O(n)

        char currentDirection = path.charAt(0); // O(1)
        char nextDirection = path.charAt(1); // O(1)

        //Compare the current node to current direction path(index:0)
        if (compare(t, currentDirection)) 
        {
        	// If left child data equals next path(index:1)
            if (t.left != null && compare(t.left, nextDirection)) // O(1)
            {
                return follow(t.left, path.substring(1)); // O(n)
                
             // If right child data equals next path(index:1)
            } else if (t.right != null && compare(t.right, nextDirection)) // O(1)
            {
                return follow(t.right, path.substring(1)); // O(n)
            }
        }
        return false; // O(1)
    }
    // here will be override
    public boolean escape1(MNode <T> t) // this function is O(n) 
    {
    	return escape(t); // O(n)
    }
    
    private boolean escape(MNode <T> t) // this function is O(n)
    {
    	// stop condition and if there is no child
        if (t == null) // O(1)
            return false; // O(1)

     // when exit found
        if (t.data.equals(Character1.X)) // O(1)
            return true; // O(1)

     // to move to the next level 
        return escape(t.left) || escape(t.right); // O(n)
    }


    public String short2() // this function is O(n)
    {
    	return short1(); // O(n)
    }
    private String short1() // this function is O(n)
    {
        MNode<T> node = root; // O(1)
        return short1(node); // O(n)
    }

    private String short1(MNode<T> node) // this function is O(n)
    {
        if (node == null)
            return "";
        
        // Check if the current node is an exit
        if (node.data.equals(Character1.X)) // O(1)
            return node.data.toString(); // O(1)
        

        // Recursively getting the shortest path
        String leftPath = short1(node.left); // O(n)
        String rightPath = short1(node.right); // O(n)

        // Determine the shortest path
        if (leftPath.isEmpty() && rightPath.isEmpty()) { // O(1)
            // No exit found
            return ""; // O(1)
        } else if (leftPath.isEmpty()) {   // O(1)
            // Exit found in the right child
            return node.data + "-" + rightPath;  // O(1)
        } else if (rightPath.isEmpty()) {  // O(1)
            // Exit found in the left child
            return node.data + "-" + leftPath; // O(1)
        } else {
            // Exit found in both, return the shortest path
            return node.data + "-" + (leftPath.length() < rightPath.length() ? leftPath : rightPath); // O(1)
        }
    }
    
    

    	

	
}
