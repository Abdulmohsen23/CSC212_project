package Project;

public enum Character1 {
	B, S, T, X
};
