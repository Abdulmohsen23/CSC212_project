package Project;

public class MNode <T>
{
	public int key; //unique number for each added node
	public T data;
	public MNode <T> left, right;
	
	public MNode(T val, int key)
	{
		data = val;
		right = left = null;
		this.key= key;
	}
	
	public MNode(T val, MNode<T> l, MNode<T> r, int key)
	{
		data = val;
		left = l;
		right = r;
		this.key= key;
	}
	
	
}
