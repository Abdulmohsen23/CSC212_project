package Project;

public enum Order 
{
	preOrder, inOrder, postOrder
};
