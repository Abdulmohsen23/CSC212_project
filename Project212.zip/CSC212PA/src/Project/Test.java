package Project;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) 
	{
		BT<Character1> b1 = new BT<>();
		
		b1.insert(Relative.Root, Character1.B);
		b1.insert(Relative.LeftChild, Character1.S);
		b1.insert(Relative.LeftChild, Character1.S);
		b1.insert(Relative.LeftChild, Character1.S);
		b1.find(Relative.Root);// 0
		b1.insert(Relative.RightChild, Character1.T);// 4
		b1.insert(Relative.LeftChild, Character1.T);
		b1.insert(Relative.LeftChild, Character1.S);
		b1.insert(Relative.LeftChild, Character1.S);// 7

		b1.find(Relative.Parent);// 6
		b1.insert(Relative.RightChild, Character1.T);
		b1.insert(Relative.LeftChild, Character1.T);
		b1.insert(Relative.RightChild, Character1.T);
		b1.insert(Relative.RightChild, Character1.X);// 11
		b1.find(Relative.Root);// 0
		b1.find(Relative.RightChild);// 4
		b1.find(Relative.LeftChild);// 5
		b1.insert(Relative.RightChild, Character1.T);// 12
		b1.insert(Relative.RightChild, Character1.S);
		b1.insert(Relative.LeftChild, Character1.T);// 14
		b1.find(Relative.Root);// 0
		b1.find(Relative.RightChild);// 4
		b1.insert(Relative.RightChild, Character1.S);// 15
		b1.insert(Relative.RightChild, Character1.S);// 16
		b1.insert(Relative.RightChild, Character1.X);// 17

		b1.find(Relative.Root);
		b1.find(Relative.RightChild);
		b1.find(Relative.LeftChild);
		b1.find(Relative.LeftChild);
		b1.find(Relative.RightChild);
		b1.find(Relative.LeftChild);
		b1.find(Relative.Parent);
		b1.find(Relative.Parent);
		b1.find(Relative.Root);
		
		b1.find(Relative.Root);
		b1.find(Relative.RightChild);
		b1.find(Relative.RightChild);

		System.out.println(b1.current.key);
		int x = 0;
		System.out.println("Hello if you want to find if your bath is correct enter 1");
		System.out.println("if you want to know if you can escape enter 2");
		System.out.println("if you want to know the shortest path enter 3");
		
		int choice;
		Scanner input = new Scanner(System.in);
		choice = input.nextInt();
		while(true)
		{
		
		switch(choice)
		{
			case 1:
				System.out.println("Please enter the path in this format X-X-X");
				b1.followPath(b1.current, input.next() );
				break;
			case 2:
				boolean esc = b1.escape1(b1.current);
				System.out.println((esc ? "You find the exit" : "sorry, you did not find the exit"));
				break;
			case 3:	
				System.out.print("The shortest path is: ");
				System.out.println(b1.short2());
				break;
				
			default:
				System.out.println("Please enter valid data!!!");
				
		}
		
		System.out.println("----------------------------------------------------------------------------");

		System.out.println("if you want to shut down the program enter -1 otherwise enter any number");
		x = input.nextInt();
		if (x == -1)
			break;
		
		System.out.println("Hello if you want to find if your bath is correct enter 1");
		System.out.println("if you want to know if you can escape enter 2");
		System.out.println("if you want to know the shortest path enter 3");
		choice = input.nextInt();
		
		
		
		
		
		
		}
		

	}

}
